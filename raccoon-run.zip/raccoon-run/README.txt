<<*README*>>

Raccoon Run
created by spiderpig_20
released March 25, 2022
v1.0.0 release

<<*CONTROLS*>>

Mouse to move and run from raccoon
SPACE to pause game


<<*CHANGELOG*>>

v1.0.0 - game now exists






NOTICE NOTICE NOTICE NOTICE NOTICE NOTICE NOTICE

do not redistribute,

you may alter the game files for PERSONAL USE ONLY 